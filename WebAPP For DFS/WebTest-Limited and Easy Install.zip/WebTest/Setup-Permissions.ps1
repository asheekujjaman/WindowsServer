param([string]$Path="C:\Shares\Data",[string]$ReadGroup="DOMAIN\FileReaders",[string]$ModifyGroup="DOMAIN\FileEditors")
New-Item -ItemType Directory -Force $Path | Out-Null
icacls $Path /inheritance:r
icacls $Path /grant:r "SYSTEM:(OI)(CI)(F)" "BUILTIN\Administrators:(OI)(CI)(F)" "$ReadGroup:(OI)(CI)(RX)" "$ModifyGroup:(OI)(CI)(M)"
New-Item -ItemType Directory -Force (Join-Path $Path ".recycle") | Out-Null
Write-Host "Review recycle ACL design in IMPLEMENTATION.txt before production use."
