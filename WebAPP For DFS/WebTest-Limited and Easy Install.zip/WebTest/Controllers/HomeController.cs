using Microsoft.AspNetCore.Mvc;using WebTest.Services;
namespace WebTest.Controllers;public sealed class HomeController(ConfigStore cfg):Controller{public IActionResult Index(){ViewBag.Config=cfg.Get();ViewBag.Health=HealthCache.Values;return View();}public IActionResult Error()=>View();}
