param([string]$SiteName="FileSharePortal")
Import-Module WebAdministration
if(Test-Path "IIS:\Sites\$SiteName"){Remove-Website $SiteName}
if(Test-Path "IIS:\AppPools\$SiteName"){Remove-WebAppPool $SiteName}
Get-NetFirewallRule -DisplayName "$SiteName HTTPS" -ErrorAction SilentlyContinue | Remove-NetFirewallRule
