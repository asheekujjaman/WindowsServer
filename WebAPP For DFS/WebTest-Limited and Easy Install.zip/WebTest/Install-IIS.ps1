param([string]$SiteName="FileSharePortal",[string]$Path="C:\inetpub\FileSharePortal",[string]$HostName="files.lab.com",[string]$Thumbprint,[string]$Gmsa="DOMAIN\svc-files$")
Import-Module WebAdministration
if(-not (Test-Path $Path)){New-Item -ItemType Directory $Path | Out-Null}
Copy-Item "$PSScriptRoot\publish\*" $Path -Recurse -Force
New-WebAppPool $SiteName
Set-ItemProperty "IIS:\AppPools\$SiteName" managedRuntimeVersion ""
Set-ItemProperty "IIS:\AppPools\$SiteName" processModel.identityType 3
Set-ItemProperty "IIS:\AppPools\$SiteName" processModel.userName $Gmsa
Set-ItemProperty "IIS:\AppPools\$SiteName" processModel.password ""
New-Website -Name $SiteName -PhysicalPath $Path -ApplicationPool $SiteName -Port 80 -HostHeader $HostName
New-WebBinding -Name $SiteName -Protocol https -Port 443 -HostHeader $HostName -SslFlags 1
if($Thumbprint){(Get-WebBinding -Name $SiteName -Protocol https).AddSslCertificate($Thumbprint,"My")}
New-NetFirewallRule -DisplayName "$SiteName HTTPS" -Direction Inbound -Protocol TCP -LocalPort 443 -Action Allow
Write-Host "Install complete. Configure HTTPS redirect and Windows Authentication in IIS Manager."
