using System.Collections.Concurrent;
namespace WebTest.Services;
public sealed record LiveSession(string Id,string User,string Ip,string Browser,DateTimeOffset SignedIn,DateTimeOffset LastActivity,string Current,bool Admin);
public sealed class SessionRegistry { readonly ConcurrentDictionary<string,LiveSession> s=new(); public IEnumerable<LiveSession> All=>s.Values.OrderByDescending(x=>x.LastActivity); public void Touch(LiveSession x)=>s[x.Id]=x; public void Kick(string id)=>s.TryRemove(id,out _); public void KickAll()=>s.Clear(); }
